.. cmake-module:: ../../Modules/FindVulkan.cmake
