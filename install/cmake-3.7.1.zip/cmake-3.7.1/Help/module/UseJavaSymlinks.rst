.. cmake-module:: ../../Modules/UseJavaSymlinks.cmake
